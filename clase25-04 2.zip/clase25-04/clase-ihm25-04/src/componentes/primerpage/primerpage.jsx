import {Link} from "react-router-dom"

const Primerpage =() => {
    return(

<div>
    <div className = "containerrmp">
        <div className="contentmp">
            <h1>Clavelina</h1>
                <br/><br/>
                <h3>Información:</h3>
                <p>La clavelina tiene su origen en Asia y es de esas plantas perennes que se reconocen a simple vista por su vistosidad y color, ya que su presencia en cualquier jardín hace que este se vea mucho más hermoso.</p>
                <br/>
                <p>Aunque pertenece a la familia del clavel, su propio nombre nos indica que su tamaño es más reducido. Alcanza como máximo los 50 centímetros (aunque su tamaño habitual es de alrededor de 25-30 centímetros). Se compone de tallos relativamente finos de los que brotan unas hojas de un color verde suave, acompañadas de unas preciosas flores con un diámetro de unos tres centímetros, con una variedad característica de tonalidades y pétalos anchos.</p>
                <br/>
                <p>Es muy habitual ver posarse sobre los pétalos de las clavelinas a abejas o mariposas.</p>
                <br/>
                <h3>Cuidados:</h3>
                <p>Las clavelinas son muy agradecidas y no requieren de un cuidado constante, aunque conviene seguir una serie de pasos para su correcta floración.</p>
                <div>
                    <ul>
                        <li>Riego. En verano necesitan agua con frecuencia, no así durante el resto del año. Se recomienda regarlas diariamente durante las temporadas más cálidas y dos veces por semana el resto de la temporada.</li>
                        <li>Cuidado de la tierra. Lo recomendable es plantarlas de forma agrupada, en sustrato poroso y aireado.</li>
                        <li>Luz. Es uno de los aspectos más importantes en el cuidado de la clavelina, y es que esta planta necesita mucha luz, con exposición directa en cualquier época del año. Este es uno de los requisitos indispensables para que su desarrollo se vea limitado.</li>
                        <li>Ubicación. Son adecuadas tanto para exterior como para interior, aunque su localización habitual suele ser en jardines y terrazas. Además, dada su necesidad de luz directa, el exterior suele ser la mejor elección, aunque no es una condición necesaria.</li>
                        <li>Temperatura. Se adapta a todo tipo de climas, también a los fríos, aunque se siente más cómoda en climas templados o cálidos. La primavera es el periodo ideal para plantar la clavelina.</li>
                        <li>Plagas. Con los cuidados adecuados la clavelina no debería tener problemas de plagas o enfermedades, pero habría que tener atención con la roya, un hongo que empezará a detectarse en las hojas mediante unos puntitos amarillos. Para evitarla, lo ideal es evitar la humedad excesiva, especialmente cuando la temperatura es baja.</li>
                    </ul>
                </div>
                <br />
                <h3>¿Donde plantar?</h3>
                <p>La clavelina se puede cultivar en maceta y también en jardín. La semilla germina en temperaturas moderadas, entre 15 °C y 20 °C. Es recomendable plantarlas en grupos, mejorando también su visibilidad y presencia. Hay que tener en cuenta que es importante que reciba exposición directa del sol, por lo que debes evitar la sobreexposición de las plantas. Recuerda que el suelo debe tener buen drenaje y, en caso de plantarse en macetas, no debería acumular agua en su base.</p>
                <br />
                <br />
            <Link to='/'><button>Inicio</button></Link>
            <Link to='/primer'><button>Clavelina</button></Link>
            <Link to='/segundo'><button>Lirio</button></Link>
            <Link to='/tercera'><button>Gardenia</button></Link>
            <Link to='/cuarto'><button>Sakura</button></Link>
            <Link to='/quinto'><button>Girasol</button></Link>
        </div>
    </div>
</div>
    )
}

export {Primerpage}   ;