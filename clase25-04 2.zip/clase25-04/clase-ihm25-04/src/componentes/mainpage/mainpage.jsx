import {Link} from "react-router-dom"

const Mainpage =() => {
    return(

<div>
    <div className = "containerrmp">
        <div className="contentmp">
            <h1>Bienvenidos</h1>
            <br/>
            <h2>Esta tu pagina favoritaaaa, compra flores y ayuda al medio ambiente. 🐝 🌺</h2>
            <p>Comienza conociendo un poco de las flores y platas que mas te gusten, escoge y da clic en el boton que desees.</p>
            <br />
            <br />
            <Link to='/'><button>Inicio</button></Link>
            <Link to='/primer'><button>Clavelina</button></Link>
            <Link to='/segundo'><button>Lirio</button></Link>
            <Link to='/tercera'><button>Gardenia</button></Link>
            <Link to='/cuarto'><button>Sakura</button></Link>
            <Link to='/quinto'><button>Girasol</button></Link>

        </div>
    </div>
</div>
    )
}

export default Mainpage   ;