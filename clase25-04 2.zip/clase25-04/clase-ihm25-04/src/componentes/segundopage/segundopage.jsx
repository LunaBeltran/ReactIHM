import {Link} from "react-router-dom"

const Segundopage =() => {
    return(

<div>
    <div className = "containerrmp">
        <div className="contentmp">
        <h1>Lirio</h1>
            <br/>
            <h3>Información:</h3>
            <p>El lirio, también conocido como azucena, flor de lis o lilium es una de las plantas bulbosas más bonitas y populares. Sus flores son muy características por su forma de trompeta y su olor tan intenso, aunque es cierto que algunas variedades no son perfumadas. Se trata de una planta muy apreciada en el Feng Shui, ya que atrae buena energía al interior de la casa. Según Interflora, los lilium en colores llamativos, como el naranja o el amarillo, aportan una dosis extra de energía y vitalidad, además de dotar de alegría al ambiente.  </p>
            <br/>
            <h3>Características:</h3>
            <div>
                    <ul>
                        <li>Los lirios son plantas bulbosas con unas flores muy sofisticadas. Se diferencian de otras flores por su tallo tan alargado, que pueden llegar a medir hasta 2 metros. ¡Impresionante! En cuanto a sus cuidados, que leerás más adelante, los lirios no necesitan mucho sol. Los lirios son flores de semisombra. Nunca deben recibir sol directo.</li>
                        <li>Otro aspecto que siempre hay que tener en mente a la hora de colocar los lirios es que cuentan con un olor muy intenso. Los lirios contienen feniletilamina, una sustancia que estimula la producción de endorfinas en el cuerpo, y proporciona una sensación de tranquilidad y bienestar. Por eso, se aconseja colocar los lirios en espacios amplios y abiertos como el salón. Aunque es cierto que hay variedades de lirios que no cuentan con aromas.</li>
                    </ul>
                </div>
            <br/>
            <h3>Significado:</h3>
            <p>El lirio o azucena es una flor llena de magia y encanto. Desde hace muchos años, el lirio ha sido considerado como una flor muy ligada a los dioses. En la antigua Grecia y Egipto se utilizan los lirios para hacer ofrendas a los dioses como muestra de gratitud. También los lirios están muy ligados al arte. Muchos artistas como Shakespeare, Van Gogh o Monet han incluido en sus obras los lirios o azucenas.</p>
            <br />
            <Link to='/'><button>Inicio</button></Link>
            <Link to='/primer'><button>Clavelina</button></Link>
            <Link to='/segundo'><button>Lirio</button></Link>
            <Link to='/tercera'><button>Gardenia</button></Link>
            <Link to='/cuarto'><button>Sakura</button></Link>
            <Link to='/quinto'><button>Girasol</button></Link>

        </div>
    </div>
</div>
    )
}

export {Segundopage}   ;