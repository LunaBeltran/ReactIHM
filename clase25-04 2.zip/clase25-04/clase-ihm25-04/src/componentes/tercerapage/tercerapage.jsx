import {Link} from "react-router-dom"

const Tercerapage =() => {
    return(

<div>
    <div className = "containerrmp">
        <div className="contentmp">
            <h1>Gardenia</h1>
                <br/>
                <h3>Información:</h3>
                <p>Son arbustos de hojas perennes de color verde claro, brillantes y lisas. Sus flores son blancas, similares a las rosas y se usan comúnmente como plantas ornamentales. Una flor, colocada en un vasito con agua, puede perfumar con un intenso y agradable aroma una habitación durante un par de días.</p>
                <br/>
                <h3>Características:</h3>
                <p>La gardenia es una planta con flor que se puede cultivar tanto en interior como exterior. Es fácil de cuidar y no necesita un mantenimiento muy específico aunque no tolera bien los cambios de rutina. En cuanto a su origen, procede del sur de China y existen muchas variedades, la más común es la Gardenia Jasminoides. Es una planta de hoja perenne de color verde que puede llegar a medir hasta un metro en el exterior. En maceta no suele crecer tanto. </p>
                <br/>
                <h3>Cuidados:</h3>
                <p>La gardenia es una planta con una buena floración y que casi no necesita cuidados. Aunque es cierto que no le gustan mucho los cambios de rutina. De aspecto es muy similar a las rosas. Aquí encontrarás algunos cuidados básicos si te animas a añadir en tu casa esta planta tan bonita: </p>
                <div>
                    <ul>
                        <li>Luz. Es una planta que necesita mucha luz. De modo que si la añades en el interior de la casa debes situar en un rincón muy iluminado, puede ser cerca de la ventana. </li>
                        <li>Riego. En verano la gardenia puede sufrir más por lo que hay que incidir con el riego, preferiblemente por inmersión. Esto significa que puedes introducir la maceta en un recipiente de agua y dejarla unos 15 minutos. También es bueno pulverizar agua sobre las hojas para que no se sequen, aunque siempre hay que evitar mojar las flores.</li>
                        <li>Temperatura. La gardenia puede crecer perfectamente entre los 30 °C y los 15 °C.</li>
                        <li>Sustrato. Ya sea en el jardín o cultivada en maceta en el interior, la gardenia necesita un sustrato ácido y que siempre esté húmedo.</li>
                        <li>Plagas. Las gardenias son plantas que tienen algunos problemas con las plagas, sobre todo los pulgones, la araña roja y las cochinillas.</li>
                    </ul>
                </div>
                <br/>
                <h3>¿Donde poner?</h3>
                <p>La ventaja de esta bonita flor es que puedes cultivarla tanto en interior como exterior. Es una planta que se adapta fácilmente a terrazas, jardines o incluso a un salón luminoso. Lo único que debes tener siempre en cuenta es la luz para que crezca bien. </p>
                <br />
                <br />
            <Link to='/'><button>Inicio</button></Link>
            <Link to='/primer'><button>Clavelina</button></Link>
            <Link to='/segundo'><button>Lirio</button></Link>
            <Link to='/tercera'><button>Gardenia</button></Link>
            <Link to='/cuarto'><button>Sakura</button></Link>
            <Link to='/quinto'><button>Girasol</button></Link>

        </div>
    </div>
</div>
    )
}

export {Tercerapage}   ;