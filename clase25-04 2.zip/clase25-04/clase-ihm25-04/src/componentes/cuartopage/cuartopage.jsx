import {Link} from "react-router-dom"

const Cuartopage =() => {
    return(

<div>
    <div className = "containerrmp">
        <div className="contentmp">
            <h1>Sakura</h1>
                <br/>
                <h3>Información:</h3>
                <p>La flor de cerezo, también conocida como sakura en japonés, es una de las flores más emblemáticas y hermosas del mundo, y en especial en Japón, donde es un símbolo de profunda importancia cultural y emocional. Tanto, que cada primavera se espera con mucha emoción porque las calles se llenan de su hermoso rosa pálido.</p>
                <br/>
                <h3>Origen:</h3>
                <p>Las flores de cerezo son originarias de Asia Oriental y se han cultivado en Japón durante más de mil años. La historia de esta hermosa flor está ligada a la cultura japonesa y se remonta a los tiempos antiguos. Se cree que las primeras cerezas silvestres florecieron en el período Jomon (14,000-300 a.C.), aunque no eran tan atractivas como las variedades cultivadas posteriormente.</p>
                <p>El cultivo fue especialmente seleccionado a lo largo de los siglos, dando lugar a las flores que conocemos hoy en día.</p>
                <p>Durante el período Heian (794-1185 d.C.), la aristocracia japonesa adoptó la costumbre de contemplar la belleza de las flores de cerezo en una práctica conocida como hanami. Esta tradición sigue viva en la actualidad y se celebra durante la temporada de floración de sakura, que generalmente ocurre en primavera.</p>
                <br />
                <h3>Clima:</h3>
                <div>
                    <ul>
                        <li>Inviernos fríos: las flores de cerezo requieren un período de invierno frío para descansar y acumular energía para la primavera.</li>
                        <li>Primaveras moderadas: la floración de los cerezos se produce en primavera, así que necesitan primaveras moderadamente frescas.</li>
                        <li>Evita las heladas tardías: las heladas tardías dañan los brotes y flores de cerezo en desarrollo.</li>
                        <li>Luz solar: las flores de cerezo necesitan una cantidad adecuada de luz solar para prosperar.</li>
                        <li>Cambio de estaciones: la transición gradual de las estaciones, con inviernos fríos y primaveras suaves, es esencial para que los cerezos florezcan en su momento adecuado.</li>
                    </ul>
                </div>
                <br />
                <br />
            <Link to='/'><button>Inicio</button></Link>
            <Link to='/primer'><button>Clavelina</button></Link>
            <Link to='/segundo'><button>Lirio</button></Link>
            <Link to='/tercera'><button>Gardenia</button></Link>
            <Link to='/cuarto'><button>Sakura</button></Link>
            <Link to='/quinto'><button>Girasol</button></Link>

        </div>
    </div>
</div>
    )
}

export {Cuartopage}   ;