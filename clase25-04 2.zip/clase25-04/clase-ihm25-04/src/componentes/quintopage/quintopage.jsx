import {Link} from "react-router-dom"
import './quintopage.css'

const Quintopage =() => {
    return(

<div>
    <div className = "containerrmp">
        <div className="contentmp">
        <h1>Girasol</h1>
            <br/>
                <h3>Información:</h3>
                <div className="imagen">
                <p>Los girasoles, con su radiante belleza y su imponente presencia, han cautivado la atención y el asombro de la humanidad durante siglos. Estas flores majestuosas, conocidas científicamente como Helianthus annuus, son verdaderas maravillas de la naturaleza que se destacan por su peculiar comportamiento y sus múltiples usos.</p>
                <img src="https://www.publico.es/ahorro-consumo-responsable/wp-content/uploads/2022/09/sunflower-1024x682.jpg" alt="" width={400} height={300}/>
            </div>
            <br/>
            <h3>¿Donde poner?</h3>
            <p>Los girasoles son plantas que requieren de una exposición solar adecuada para su crecimiento óptimo. Por lo tanto, elige un lugar en tu jardín, terraza o patio que reciba la mayor cantidad de luz solar posible y que sea suficientemente ancho para permitir su desarrollo. ¡Son plantas que pueden crecer hasta ser bastante altas!</p>
            <p>A su vez, asegúrate de plantarlos en un suelo bien drenado que no sea propenso a encharcar el agua y que sea ligeramente arenoso y fértil. Si es posible, busca un lugar protegido de vientos fuertes y orientados hacia el este para que cuando se vaya el sol hacia el oeste hayan aprovechado toda la luz solar posible. </p>
            <br />
            <h3>Origen y significado:</h3>
            <p>Los girasoles son una planta herbácea originaria de Centro y Norteamérica, aunque actualmente se cultivan en zonas muy diversas. Su relación con el sol es de sobra conocida: lo llevan implícito en su nombre, lo miran para nutrirse de sus rayos y sus colores nos lo recuerdan. Precisamente sus tonalidades los convierten también en símbolos de infancia, buena energía y vitalidad.</p>
            <p>Ya en la mitología griega, los girasoles representaban a los dioses del sol y simbolizaban la adoración al astro rey. En la cultura popular contemporánea, los girasoles también se han asociado con sentimientos de optimismo y alegría, transmitiendo un mensaje de esperanza incluso en los momentos más oscuros.</p>
            <br />
            <h3>Cuidados de un girasol cortado:</h3>
                <p>Presta atención a las siguientes claves para cuidar girasoles cortados que nos ha facilitado la experta de Colvin Mireia Aldomà:</p>
                <div>
                    <ul>
                        <li>Riego. Lo ideal es regarlos con agua fresquita cada día o cada dos días. Eso sí, conviene evitar siempre que haya pétalos u hojas en el agua, pues esto puede provocar que se pudra el tallo o se deteriore la flor.</li>
                        <li>Vitaminas. Según Mireia, es básico agregar siempre "flower food" para mantener las plantas bonitas y bien hidratadas. En sus palabras, este alimento "es como nuestro café de la mañana". Aunque también nos deja un alternativa casera: las aspirinas.</li>
                        <li>Lugar. Los girasoles deben colocarse en un sitio fresco al que no llegue luz solar directa. Además, debemos evitar que el ramo esté cerca de cualquier aparato que emita calor, aire frío, vapor o similares. Y es que las flores huyen de las temperaturas extremas.</li>
                        <li>Corta el tallo. Por último, Mireia nos da un truco de florista: corta el tallo en diagonal, y no recto, para que absorba más agua, repitiendo esta acción cada dos días. Y, por supuesto, mima las plantas.</li>
                    </ul>
                </div>
            <br />
            <br />
            <Link to='/'><button>Inicio</button></Link>
            <Link to='/primer'><button>Clavelina</button></Link>
            <Link to='/segundo'><button>Lirio</button></Link>
            <Link to='/tercera'><button>Gardenia</button></Link>
            <Link to='/cuarto'><button>Sakura</button></Link>
            <Link to='/quinto'><button>Girasol</button></Link>

        </div>
    </div>
</div>
    )
}

export {Quintopage}   ;